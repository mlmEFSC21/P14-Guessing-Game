let guesses = [];
// let currentGuess = parseInt(prompt("Pick a number between 1 and 1000 (inclusive)!"));

for (i = 0; i < 100; i++) {
    let randomNumber = Math.floor(Math.random() * 1000 + 1);
    console.log(randomNumber);
}

// console.log(currentGuess);
