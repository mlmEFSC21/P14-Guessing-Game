let guesses = [];
let currentGuess = parseInt(prompt("Pick a number between 1 and 1000 (inclusive)!"));

console.log(currentGuess);
