let randomNumber = Math.floor(Math.random() * 1000 + 1);
let guesses = [];
let currentGuess = parseInt(prompt("Pick a number between 1 and 1000 (inclusive)!"));

//logging random number for debugging. DELETE LATER
console.log(randomNumber);
console.log(currentGuess);
