# P14-Guessing-Game
Module 9 Project 1 (Guess the Number Game)

Requirements
Write a script that plays a “guess the number” game as follows:

Your program chooses the number to be guessed by selecting a random integer in the range 1 to 1000. The script displays the prompt Guess a number between 1 and 1000 next to a text field. The player types a first guess into the text field and clicks a button to submit the guess to the script. If the player's guess is incorrect, your program should display either Too high, try again or Too low, try again to help the player “zero in” on the correct answer and should clear the text field so the user can enter the next guess. When the user enters the correct answer, display Congratulations! You guessed the number! and clear the text field so the user can play again.
